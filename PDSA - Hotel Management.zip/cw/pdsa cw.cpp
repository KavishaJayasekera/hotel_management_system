#include <iostream>
using namespace std;

class Hotel
{
private:
    struct Node
    {
        int id, date;
        string name, roomtype;
        Node* next; //A pointer to the next node in the sequence
        Node* prev; // Added a previous pointer for doubly linked list
    };

public:
    Node* head = nullptr;
    void insert();
    void menu();
    void update();
    void search();
    void del();
    void sort();
    void show();

private:
    // Helper functions for Quick Sort
    void quickSort(Node* low, Node* high);
    Node* partition(Node* low, Node* high);
    void swapNodes(Node* a, Node* b);
};

void Hotel::menu()
{
    int selection;
    do
    {
        cout << "\n";
        cout << "\t*-*-*-*-*WELCOME TO KANDALAMA HERITANCE HOTEL-*-*-*-*-*\n"
             << endl;
        cout << "\n\t ------ Hotel Heritance Management System ------";
        cout << "\n\nNo      Functions               Description" << endl;
        cout << "\n1\tReserve Room\t\tInsert New Room";
        cout << "\n2\tSearch Room\t\tSearch Room with RoomID";
        cout << "\n3\tUpdate Room\t\tUpdate Room Record";
        cout << "\n4\tDelete Room\t\tDelete Room with RoomID";
        cout<<"\n5\tShow Room Records\tShow Room Records that (we Added)";
        cout << "\n6\tSort Rooms\t\tSort Rooms by RoomID";
        cout << "\n7\tExit" << endl;

        cout << "\nProvide your selection: ";
        cin >> selection;

        switch (selection)
        {
        case 1:
            insert();
            menu();
        case 2:
            search();
            menu();
        case 3:
            update();
            menu();
        case 4:
            del();
            menu();
        case 5:
            show();
            menu();
        case 6:
            sort();
            //show(); // Display the sorted list
            menu();
        case 7:
            cout << "Exiting the program. Goodbye!" << endl;
            break;
        default:
            cout << "Invalid selection, please try again." << endl;
        }
    } while (selection != 7);
}

void Hotel::insert()
{
    cout << "\n\t------ Hotel Management System ------";

    Node* new_node = new Node;
    cout << "\n\nEnter Room ID : ";
    cin >> new_node->id;
    cout << "\nEnter Customer Name : ";
    cin >> new_node->name;
    cout << "\nEnter Reservation Date : ";
    cin >> new_node->date;
    cout << "\nEnter Room Type (single/double/twin/family) : ";
    cin >> new_node->roomtype;

    if (head == nullptr)
    {
        head = new_node;
        head->prev = nullptr; // Initialize the previous pointer for the first node
    }
    else
    {
        Node* ptr = head;
        while (ptr->next != nullptr)
        {
            ptr = ptr->next;
        }
        ptr->next = new_node;
        new_node->prev = ptr; // Set the previous pointer for the new node
    }

    cout << "\n\t\t New Room Inserted\n\n";
    menu();
}

void Hotel::search()
{
    cout << "\n\t------ Hotel Heritance Management System ------";
    int t_id;

    if (head == nullptr)
    {
        cout << "\n\nLinked List is Empty";
    }
    else
    {
        cout << "\n\nEnter Room ID to Search: ";
        cin >> t_id;
        Node* ptr = head;
        while (ptr != nullptr)
        {
            if (t_id == ptr->id)
            {
                cout << "\n\nRoom ID : " << ptr->id;
                cout << "\n\nCustomer Name : " << ptr->name;
                cout << "\n\nRoom Reservation Date : " << ptr->date;
                cout << "\n\nRoom Type : " << ptr->roomtype << endl;
                return; // Added to exit the function after finding the room
            }
            ptr = ptr->next;
        }
       // cout << "Room with ID " << t_id << " not found." << endl;
    }
}

void Hotel::update()
{
    cout << "\n\n\t------ Hotel Heritance Management System ------";
    int t_id;

    if (head == NULL)
    {
        cout << "\n\nLinked List is Empty";
    }
    else
    {
        cout << "\n\nEnter Room ID to Update: ";
        cin >> t_id;
        Node* ptr = head;
        while (ptr != nullptr)
        {
            if (t_id == ptr->id)
            {
                cout << "\n\nRoom ID :";
                cin >> ptr->id;

                cout << "\n\nCustomer Name :";
                cin >> ptr->name;

                cout << "\n\nReservation Date :";
                cin >> ptr->date;

                cout << "\n\nRoom Type :";
                cin >> ptr->roomtype;

                cout << "\n\n\t\t *Update Record Successfully\n\n";
                return; // Added to exit the function after updating the record
            }
            ptr = ptr->next;
        }
        cout << "Room with ID " << t_id << " not found." << endl;
    }
}

void Hotel::del()
{
    cout<<"\n\t------ Hotel Heritance Management System ------";
    int t_id;

    if(head==NULL)
    {
        cout<<"\n\nLinked List is Empty";
    }

    else
    {
        cout<<"\n\nRoom ID :";
        cin>>t_id;
        if(t_id == head->id)
        {
            Node* ptr = head;
            head = head->next;
            delete ptr;
            cout<<"\n\n\t\t *Deleted Room Record Successfully\n";
        }
        else
        {
            Node* ptr = head;
            Node* pre = head;
            while(ptr!=NULL)
            {
                if(t_id == ptr->id)
                {
                    pre->next=ptr->next;
                    delete ptr;
                    cout<<"\n\n\t\t *Delete Room Record Successfully\n\n";
                    break;
                }
                pre = ptr;
                ptr=ptr->next;
            }
        }


    }
}

void Hotel::show()
{
    Node* ptr = head;
    while(ptr!= NULL)
    {
        cout<<"\n\nRoom ID :"<<ptr->id;

        cout<<"\n\nCustomer Name :"<<ptr->name;

        cout<<"\n\nReservation Date :"<<ptr->date;

        cout<<"\n\nRoom Type :"<<ptr->roomtype;
        menu();

        ptr =ptr->next;
    }

}

void Hotel::sort()
{
    if(head==NULL)
    {
        cout<<"\n\nLinked List is Empty";
        menu();
    }
        int count = 0;
        int t_date,t_id;
        string t_name, t_roomtype;
        Node*ptr = head;
        while(ptr!=NULL)
        {
            count++;
            ptr =ptr->next;
        }
        for(int i =1; i<=count; i++)
        {
            Node* ptr = head;
            for(int j=1; j<count; j++)
            {
                if(ptr->id > ptr->next->id)
                    {
                        t_id=ptr->id;
                        t_name=ptr->name;
                        t_date=ptr->date;
                        t_roomtype=ptr->roomtype;
                        //Save Date Into Current Node
                        ptr->id=ptr->next->id;
                        ptr->name=ptr->next->name;
                        ptr->date=ptr->next->date;
                        ptr->roomtype=ptr->next->roomtype;
                        //Save Date Into Next Node
                        ptr->next->id = t_id;
                        ptr->next->name = t_name;
                        ptr->next->date = t_date;
                        ptr->next->roomtype = t_roomtype;

                    }
            }
        }
    }

 int main()
 {
     Hotel h;
     h.menu();
 }


